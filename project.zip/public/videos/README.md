# Hero Background Video

Please add a hero background video here named `hero-background.mp4`.

Recommended specifications:
- Format: MP4
- Resolution: 1920x1080 (16:9 aspect ratio)
- Encoding: H.264
- Recommended length: 10-15 seconds
- Theme: Relates to livestock, farming, or qurban animals

The video should be high-quality, professional, and align with the Surya Ternak brand.
